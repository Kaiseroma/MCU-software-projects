#include "main.h"

#include<stdint.h>

#include<math.h>

#include<stdio.h>

#include<stdlib.h>

#include<string.h>

void SystemClock_Config(void);
static void GPIO_Init(void);
static void I2C1_Init(void);
static void USART1_UART_Init(void);
static void TIM2_Init(void);
static void TIM3_Init(void);

I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart1;

TIM_HandleTypeDef htim2, htim3;

#define SET 1
#define RESET 0

#define SLAVE_ADDR_ADC 0x20

uint8_t comms_for_adc[4] = {0x00, 0xFF, 0x20, 0x01};

#define OWN_NET_ADDRESS 0x1E

#define COMMAND_82 0x23
#define COMMAND_83 0x25

uint8_t rcv_buf_i2c[16];

uint8_t i2c_to_uart_buf[16];

uint16_t telemetria_byte[8];

uint8_t uart_txe_flag;

uint8_t rcv_buf_uart[4];

uint8_t uart_ready_array[8];

uint8_t data_ready[7];

float rounded_data[8];

float u_ref = 2.5;

float adc_bit_div = pow((double)2, (double)12)-1;

float real[8];

uint8_t k, a = 0;

GPIO_InitTypeDef StopPin;

float threshold_20 = 0.0;
float threshold_9 = 0.0;
float threshold_own = 0.0;

uint8_t Crc8Table[256] = {
    0x00, 0x31, 0x62, 0x53, 0xC4, 0xF5, 0xA6, 0x97,
    0xB9, 0x88, 0xDB, 0xEA, 0x7D, 0x4C, 0x1F, 0x2E,
    0x43, 0x72, 0x21, 0x10, 0x87, 0xB6, 0xE5, 0xD4,
    0xFA, 0xCB, 0x98, 0xA9, 0x3E, 0x0F, 0x5C, 0x6D,
    0x86, 0xB7, 0xE4, 0xD5, 0x42, 0x73, 0x20, 0x11,
    0x3F, 0x0E, 0x5D, 0x6C, 0xFB, 0xCA, 0x99, 0xA8,
    0xC5, 0xF4, 0xA7, 0x96, 0x01, 0x30, 0x63, 0x52,
    0x7C, 0x4D, 0x1E, 0x2F, 0xB8, 0x89, 0xDA, 0xEB,
    0x3D, 0x0C, 0x5F, 0x6E, 0xF9, 0xC8, 0x9B, 0xAA,
    0x84, 0xB5, 0xE6, 0xD7, 0x40, 0x71, 0x22, 0x13,
    0x7E, 0x4F, 0x1C, 0x2D, 0xBA, 0x8B, 0xD8, 0xE9,
    0xC7, 0xF6, 0xA5, 0x94, 0x03, 0x32, 0x61, 0x50,
    0xBB, 0x8A, 0xD9, 0xE8, 0x7F, 0x4E, 0x1D, 0x2C,
    0x02, 0x33, 0x60, 0x51, 0xC6, 0xF7, 0xA4, 0x95,
    0xF8, 0xC9, 0x9A, 0xAB, 0x3C, 0x0D, 0x5E, 0x6F,
    0x41, 0x70, 0x23, 0x12, 0x85, 0xB4, 0xE7, 0xD6,
    0x7A, 0x4B, 0x18, 0x29, 0xBE, 0x8F, 0xDC, 0xED,
    0xC3, 0xF2, 0xA1, 0x90, 0x07, 0x36, 0x65, 0x54,
    0x39, 0x08, 0x5B, 0x6A, 0xFD, 0xCC, 0x9F, 0xAE,
    0x80, 0xB1, 0xE2, 0xD3, 0x44, 0x75, 0x26, 0x17,
    0xFC, 0xCD, 0x9E, 0xAF, 0x38, 0x09, 0x5A, 0x6B,
    0x45, 0x74, 0x27, 0x16, 0x81, 0xB0, 0xE3, 0xD2,
    0xBF, 0x8E, 0xDD, 0xEC, 0x7B, 0x4A, 0x19, 0x28,
    0x06, 0x37, 0x64, 0x55, 0xC2, 0xF3, 0xA0, 0x91,
    0x47, 0x76, 0x25, 0x14, 0x83, 0xB2, 0xE1, 0xD0,
    0xFE, 0xCF, 0x9C, 0xAD, 0x3A, 0x0B, 0x58, 0x69,
    0x04, 0x35, 0x66, 0x57, 0xC0, 0xF1, 0xA2, 0x93,
    0xBD, 0x8C, 0xDF, 0xEE, 0x79, 0x48, 0x1B, 0x2A,
    0xC1, 0xF0, 0xA3, 0x92, 0x05, 0x34, 0x67, 0x56,
    0x78, 0x49, 0x1A, 0x2B, 0xBC, 0x8D, 0xDE, 0xEF,
    0x82, 0xB3, 0xE0, 0xD1, 0x46, 0x77, 0x24, 0x15,
    0x3B, 0x0A, 0x59, 0x68, 0xFF, 0xCE, 0x9D, 0xAC
};

int main(void)
{
  //PERIPHERAL INITS
  HAL_Init();
  SystemClock_Config();
  GPIO_Init();
  I2C1_Init();
  USART1_UART_Init();
  TIM2_Init();
  TIM3_Init();

  HAL_PWR_EnableSleepOnExit();

  while( HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) != GPIO_PIN_SET); //WAITING UNTIL FPGA IS READY

  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_SET); //TURNING ON PA

  data_ready[1] |= ( 1 << 1 );     //SETTING THE PAF FLAG

  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET); //ENABLING I2C VOLTAGE LEVEL RETRANSLATOR

  //WRITING COMMANDS TO ADC

  while ( HAL_I2C_Master_Transmit(&hi2c1, (uint16_t)SLAVE_ADDR_ADC << 1, (uint8_t*)&comms_for_adc, 4, HAL_MAX_DELAY) != HAL_OK);

  HAL_TIM_Base_Start_IT(&htim2);
  HAL_TIM_Base_Start_IT(&htim3);

  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_RESET);  //1 ENABLING MAX2250 RECEIVER

  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, GPIO_PIN_SET);    //2 ENABLING MAX2250 TRANSCEIVER

  while (1)
  {
	 //RECEIVING COMMANDS FOR FPGA

	 HAL_UART_Receive_IT(&huart1, (uint8_t*)&rcv_buf_uart, 4);
  }
}

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  //RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  //RCC_OscInitStruct.HSEState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
	Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSE;
  //RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
	  Error_Handler();
  }
}

static void I2C1_Init(void)
{
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  hi2c1.Mode = HAL_I2C_MODE_MASTER;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
	  Error_Handler();
  }
}
static void USART1_UART_Init(void)
{
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
	  Error_Handler();
  }
}
static void GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  uint32_t gpio_pins = GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Pin = gpio_pins;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  gpio_pins = GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Pin = gpio_pins;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  HAL_NVIC_SetPriority(EXTI9_5_IRQn,11,0);

}
static void TIM2_Init(void)
{
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 31;
  htim2.Init.Period = 24999;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if( HAL_TIM_Base_Init(&htim2) != HAL_OK )
  {
	  Error_Handler();
  }
}
static void TIM3_Init(void)
{
	htim3.Instance = TIM3;
	htim3.Init.Prescaler = 31;
	htim3.Init.Period = 12499;
	htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if( HAL_TIM_Base_Init(&htim3) != HAL_OK )
  {
	  Error_Handler();
  }
}
void Error_Handler(void)
{
	__disable_irq();
	while (1)
    {
	}
}
void HAL_I2C_MasterRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
  //STORING ADC DATA TO BUFFER

  for(int i=0;i<=15;i++)
  {
	  i2c_to_uart_buf[i] = rcv_buf_i2c[i];
  }

  //TRANSFORMING ADC DATA

  for(int j=0;j<=7;j++)
  {
	  for(int i=j*2;i<=j*2+1;i++)
	  {
		  if (i % 2 == 0)
		  {
		    telemetria_byte[j] |= ((i2c_to_uart_buf[i] >> 3) & 1u) << 11;
		    telemetria_byte[j] |= ((i2c_to_uart_buf[i] >> 2) & 1u) << 10;
		    telemetria_byte[j] |= ((i2c_to_uart_buf[i] >> 1) & 1u) << 9;
		    telemetria_byte[j] |= ((i2c_to_uart_buf[i] >> 0) & 1u) << 8;
		  }
		  else  if (i % 2 != 0)
		  {
			telemetria_byte[j] |= ((i2c_to_uart_buf[i] >> 7) & 1u) << 7;
			telemetria_byte[j] |= ((i2c_to_uart_buf[i] >> 6) & 1u) << 6;
			telemetria_byte[j] |= ((i2c_to_uart_buf[i] >> 5) & 1u) << 5;
			telemetria_byte[j] |= ((i2c_to_uart_buf[i] >> 4) & 1u) << 4;
		    telemetria_byte[j] |= ((i2c_to_uart_buf[i] >> 3) & 1u) << 3;
		    telemetria_byte[j] |= ((i2c_to_uart_buf[i] >> 2) & 1u) << 2;
		    telemetria_byte[j] |= ((i2c_to_uart_buf[i] >> 1) & 1u) << 1;
		    telemetria_byte[j] |= ((i2c_to_uart_buf[i] >> 0) & 1u) << 0;
		  }
	  }
  }

  //MULTIPLYING telemetria_bytes TO SOME VALUES TO GET REAL PARAMETERS:

  //ADC MULTIPLYING OPERATONS

  for(int j=0;j<=7;j++)
  {
	  real[j] = telemetria_byte[j];
	  real[j] *= u_ref;
	  real[j] /= adc_bit_div;
  }

  //VOLTAGE DIVIDERS CONSIDERATION

  real[0] *= 1;

  real[1] *= 9;

  real[2] *= 6;

  real[3] *= 26;
  real[3] /= 10;

  real[4] *= 26;
  real[4] /= 16;

  real[5] *= 26;
  real[5] /= 16;

  real[6] *= 26;
  real[6] /= 16;

  real[7] *= 26;
  real[7] /= 16;

  //CONVERTING FLOAT ARRAY TO UINT_8T ARRAY

  for(int j=0;j<=7;j++)
    {
	  if( j==0 || j==3 || j==4 || j==7 )
		  uart_ready_array[j] = roundf(real[j]*100);
	  else
		  uart_ready_array[j] = roundf(real[j]);
    }

  //MAKING DATA READY ACCORDING TO PROTOCOL

  //XPG FLAG
  if((real[1] > 16.0) && (real[2] > 7.2))
      data_ready[1] |= 1 << 0;
  else data_ready[1] &= ~(1 << 0);

  //PTA FLAG
  if(real[0] > 1.77)
	  data_ready[1] |= 1 << 2;
  else data_ready[1] &= ~(1 << 2);

  //PAF FLAG IS ALREADY SET

  //OTHER TX BYTES
  data_ready[0] = (uint8_t)OWN_NET_ADDRESS;
  data_ready[2] = uart_ready_array[3];    //I_20V
  data_ready[3] = uart_ready_array[4];    //I_9V
  data_ready[4] = uart_ready_array[7];    //I_OWN
  data_ready[5] = uart_ready_array[0];    //TX_MON

  //COMPUTING CRC8

  uint8_t crc = 0xFF;
  int i = 5;
  while(i > 0)
  {
	  crc += Crc8Table[crc ^ data_ready[6-i]];   //CRC8
	  i--;
  }
  data_ready[6] = crc;

  //WE ARE READY FOR UART TRANSMITTING

  uart_txe_flag = RESET;

  //MANIPULATING FAULT\ SIGNAL - THRESHOLDS WILL BE IMPLEMENTED EXACTLY AFTER EXPERIMENTS

  if (real[3] > threshold_20 || real[4] > threshold_9 || real[7] > threshold_own)
	  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET);
  else
	  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET);
}
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    //WAITING UNTIL WE ARE READY FOR UART TRANSMITTING
	if(htim->Instance == TIM2)
	{
		if(uart_txe_flag != SET)
		{
			//UART TRANSMITTING

			HAL_UART_Transmit_IT(&huart1, (uint8_t*)&data_ready, 7);
		}
	}
	else if(htim->Instance == TIM3)
	{
		 //RECEIVING DATA FROM ADC

	     HAL_I2C_Master_Receive_IT(&hi2c1, (uint16_t)SLAVE_ADDR_ADC << 1, (uint8_t*)&rcv_buf_i2c, 16);
	}


}
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
	//WE ARE NOT READY FOR UART TRANSMITTING

	uart_txe_flag = SET;

}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	//WRITING 0 AND 1 TO SPECIAL GPIOs FOR FPGA ACCORDING TO THE COMMANDS
    if( rcv_buf_uart[0] == (uint8_t)OWN_NET_ADDRESS )
    {
	    if( rcv_buf_uart[1] == (uint8_t)COMMAND_82 )
	    {
	    	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET);
	    	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
	    }
	    else if( rcv_buf_uart[1] == (uint8_t)COMMAND_83 )
	    {
	    	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
	    	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
	    }
	    else
	    {
	    	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
	    	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
	    }
    }
    else
    {
    	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
    	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
    }
}
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(GPIO_Pin == GPIO_PIN_8)
	{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET);    //PA TURN-OFF
		data_ready[1] &= ~(1 << 1);    //PAF FLAG RESET

		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);    //DISABLING I2C VOLTAGE LEVEL RETRANSLATOR
	    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_SET);     //1 DISABLING MAX2250 RECEIVER
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, GPIO_PIN_RESET);   //2 DISABLING MAX2250 TRANSCEIVER

		HAL_PWR_EnterSTOPMode(PWR_MAINREGULATOR_ON, PWR_STOPENTRY_WFI);    //SWITCHING THE MCU TO STOP MODE
	}
}

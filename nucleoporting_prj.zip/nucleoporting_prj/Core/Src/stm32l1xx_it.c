#include "main.h"
#include "stm32l1xx_it.h"

void NMI_Handler(void)
{
  while (1)
  {
  }
}

void HardFault_Handler(void)
{
  while (1)
  {

  }
}

void MemManage_Handler(void)
{
  while (1)
  {

  }
}

void BusFault_Handler(void)
{
  while (1)
  {

  }
}

void UsageFault_Handler(void)
{
  while (1)
  {
  }
}

void SVC_Handler(void)
{

}
void DebugMon_Handler(void)
{

}

void PendSV_Handler(void)
{

}

I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart1;

TIM_HandleTypeDef htim2, htim3;

uint8_t k, a;
void SysTick_Handler(void)
{
  HAL_IncTick();
}
void TIM2_IRQHandler(void)
{
	 HAL_TIM_IRQHandler(&htim2);
}
void TIM3_IRQHandler(void)
{
	 HAL_TIM_IRQHandler(&htim3);
}
void I2C1_EV_IRQHandler(void)
{
	HAL_I2C_EV_IRQHandler(&hi2c1);
}
void I2C1_ER_IRQHandler(void)
{
	HAL_I2C_ER_IRQHandler(&hi2c1);
}
void USART1_IRQHandler(void)
{
	HAL_UART_IRQHandler(&huart1);
}
void EXTI9_5_IRQHandler(void)
{
	HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_8);
}

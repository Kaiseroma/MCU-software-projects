
#include "main.h"

void HAL_MspInit(void)
{
  __HAL_RCC_PWR_CLK_ENABLE();
 	HAL_NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);

 	SCB->SHCSR |= 0x7 << 16;

 	HAL_NVIC_SetPriority(MemoryManagement_IRQn,0,0);
 	HAL_NVIC_SetPriority(BusFault_IRQn,0,0);
 	HAL_NVIC_SetPriority(UsageFault_IRQn,0,0);
}

void HAL_I2C_MspInit(I2C_HandleTypeDef* hi2c)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_I2C1_CLK_ENABLE();
    __HAL_RCC_I2C1_CLK_SLEEP_DISABLE();

    GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF4_I2C1;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	HAL_NVIC_EnableIRQ(I2C1_ER_IRQn);

	HAL_NVIC_SetPriority(I2C1_ER_IRQn,13,0);

	HAL_NVIC_EnableIRQ(I2C1_EV_IRQn);

	HAL_NVIC_SetPriority(I2C1_EV_IRQn,15,0);

}

void HAL_I2C_MspDeInit(I2C_HandleTypeDef* hi2c)
{
    __HAL_RCC_I2C1_CLK_DISABLE();

    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_6);

    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_7);
}

void HAL_UART_MspInit(UART_HandleTypeDef* huart)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
    __HAL_RCC_USART1_CLK_ENABLE();
    __HAL_RCC_USART1_CLK_SLEEP_DISABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    GPIO_InitStruct.Pin = GPIO_PIN_9|GPIO_PIN_10;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	HAL_NVIC_EnableIRQ(USART1_IRQn);

	HAL_NVIC_SetPriority(USART1_IRQn,14,0);
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* huart)
{
    __HAL_RCC_USART1_CLK_DISABLE();

    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_9|GPIO_PIN_10);

}

void HAL_TIM_Base_MspInit(TIM_HandleTypeDef* htim)
{
	__HAL_RCC_TIM2_CLK_ENABLE();

	__HAL_RCC_TIM3_CLK_ENABLE();

	HAL_NVIC_EnableIRQ(TIM2_IRQn);

	HAL_NVIC_SetPriority(TIM2_IRQn,14,0);

	HAL_NVIC_EnableIRQ(TIM3_IRQn);

	HAL_NVIC_SetPriority(TIM3_IRQn,12,0);
}

void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef* htim)
{
	__HAL_RCC_TIM2_CLK_DISABLE();

	__HAL_RCC_TIM3_CLK_DISABLE();
}
